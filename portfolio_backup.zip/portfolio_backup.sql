--
-- PostgreSQL database dump
--

\restrict HmShIgdyt9zxFTkJUw68iyi8SfGoZ6Uft3PHZ82992ydVQwgKdLp8srKMt48Uwl

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: certificates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.certificates (
    id integer NOT NULL,
    name text NOT NULL,
    value numeric(14,2) NOT NULL,
    rate_percent numeric(6,2) NOT NULL,
    maturity_date date NOT NULL
);


--
-- Name: certificates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.certificates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: certificates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.certificates_id_seq OWNED BY public.certificates.id;


--
-- Name: funds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.funds (
    id integer NOT NULL,
    key text NOT NULL,
    name text NOT NULL,
    ticker text NOT NULL,
    icon text NOT NULL,
    units_held numeric(14,4) NOT NULL,
    cost_basis_total numeric(14,2) NOT NULL,
    nav numeric(14,4) NOT NULL,
    apy_percent numeric(6,2)
);


--
-- Name: funds_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.funds_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: funds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.funds_id_seq OWNED BY public.funds.id;


--
-- Name: gold_holdings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gold_holdings (
    id integer NOT NULL,
    grams_held numeric(12,3) NOT NULL,
    avg_cost_per_gram numeric(12,2) NOT NULL,
    market_price_per_gram numeric(12,2) NOT NULL,
    cashback_per_gram numeric(12,2) NOT NULL
);


--
-- Name: gold_holdings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gold_holdings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gold_holdings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gold_holdings_id_seq OWNED BY public.gold_holdings.id;


--
-- Name: gold_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gold_settings (
    id integer NOT NULL,
    cashback_per_gram numeric(12,2) NOT NULL
);


--
-- Name: gold_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gold_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gold_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gold_settings_id_seq OWNED BY public.gold_settings.id;


--
-- Name: gold_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gold_transactions (
    id integer NOT NULL,
    date date NOT NULL,
    quantity integer NOT NULL,
    weight_per_unit_grams numeric(10,3) NOT NULL,
    total_weight_grams numeric(10,3) NOT NULL,
    karat integer NOT NULL,
    spot_price_per_gram numeric(12,2) NOT NULL,
    manufacturing_fee_per_gram numeric(12,2) NOT NULL,
    total_paid numeric(14,2) NOT NULL
);


--
-- Name: gold_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gold_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gold_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gold_transactions_id_seq OWNED BY public.gold_transactions.id;


--
-- Name: growth_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.growth_snapshots (
    id integer NOT NULL,
    snapshot_date date NOT NULL,
    value numeric(14,2) NOT NULL
);


--
-- Name: growth_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.growth_snapshots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: growth_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.growth_snapshots_id_seq OWNED BY public.growth_snapshots.id;


--
-- Name: portfolio_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.portfolio_settings (
    id integer NOT NULL,
    emergency_fund_target numeric(14,2) NOT NULL,
    usd_egp_rate numeric(10,4) NOT NULL
);


--
-- Name: portfolio_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.portfolio_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: portfolio_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.portfolio_settings_id_seq OWNED BY public.portfolio_settings.id;


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transactions (
    id integer NOT NULL,
    asset_type text NOT NULL,
    name text NOT NULL,
    meta text NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    amount numeric(14,2) NOT NULL,
    tx_type text NOT NULL
);


--
-- Name: transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.transactions_id_seq OWNED BY public.transactions.id;


--
-- Name: certificates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.certificates ALTER COLUMN id SET DEFAULT nextval('public.certificates_id_seq'::regclass);


--
-- Name: funds id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.funds ALTER COLUMN id SET DEFAULT nextval('public.funds_id_seq'::regclass);


--
-- Name: gold_holdings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gold_holdings ALTER COLUMN id SET DEFAULT nextval('public.gold_holdings_id_seq'::regclass);


--
-- Name: gold_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gold_settings ALTER COLUMN id SET DEFAULT nextval('public.gold_settings_id_seq'::regclass);


--
-- Name: gold_transactions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gold_transactions ALTER COLUMN id SET DEFAULT nextval('public.gold_transactions_id_seq'::regclass);


--
-- Name: growth_snapshots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.growth_snapshots ALTER COLUMN id SET DEFAULT nextval('public.growth_snapshots_id_seq'::regclass);


--
-- Name: portfolio_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portfolio_settings ALTER COLUMN id SET DEFAULT nextval('public.portfolio_settings_id_seq'::regclass);


--
-- Name: transactions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions ALTER COLUMN id SET DEFAULT nextval('public.transactions_id_seq'::regclass);


--
-- Data for Name: certificates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.certificates (id, name, value, rate_percent, maturity_date) FROM stdin;
1	NBE Cert #1	15000.00	19.00	2027-04-06
2	NBE Cert #2	36000.00	19.00	2027-04-13
3	NBE Cert #3	30000.00	19.00	2027-04-18
4	NBE Cert #4	3000.00	19.00	2027-04-18
5	NBE Cert #5	16000.00	19.00	2027-04-27
6	NBE Cert #6	5000.00	19.00	2027-04-30
7	NBE Cert #7	6000.00	19.00	2026-07-13
8	NBE Cert #8	2000.00	19.00	2026-08-07
9	NBE Cert #9	2000.00	19.00	2026-08-14
10	NBE Cert #10	6000.00	19.00	2026-09-04
11	NBE Cert #11	3000.00	19.00	2026-10-10
12	NBE Cert #12	1000.00	19.00	2026-10-15
13	NBE Cert #13	5000.00	19.00	2026-10-22
14	NBE Cert #14	15000.00	19.00	2026-10-25
15	NBE Cert #15	5000.00	19.00	2026-11-09
16	NBE Cert #16	2000.00	19.00	2026-11-13
17	NBE Cert #17	4000.00	19.00	2026-11-29
18	NBE Cert #18	4000.00	19.00	2027-01-02
19	NBE Cert #19	3000.00	25.00	2027-03-11
20	NBE Cert #20	3000.00	19.25	2027-04-08
21	NBE Cert #21	5000.00	21.50	2027-04-16
22	NBE Cert #22	3000.00	21.50	2027-05-14
23	NBE Cert #23	3000.00	21.50	2027-05-20
24	NBE Cert #24	3000.00	21.50	2027-06-13
25	NBE Cert #25	30000.00	18.50	2028-06-17
\.


--
-- Data for Name: funds; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.funds (id, key, name, ticker, icon, units_held, cost_basis_total, nav, apy_percent) FROM stdin;
2	re	Beltone Real Estate Fund	BRE	🏢	2656.0000	5020.00	1.9100	\N
1	abr	Bareeq Fund	ABR	🏦	72.0000	14920.00	207.8000	23.00
\.


--
-- Data for Name: gold_holdings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gold_holdings (id, grams_held, avg_cost_per_gram, market_price_per_gram, cashback_per_gram) FROM stdin;
\.


--
-- Data for Name: gold_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gold_settings (id, cashback_per_gram) FROM stdin;
1	28.50
\.


--
-- Data for Name: gold_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gold_transactions (id, date, quantity, weight_per_unit_grams, total_weight_grams, karat, spot_price_per_gram, manufacturing_fee_per_gram, total_paid) FROM stdin;
5	2025-12-15	2	5.000	10.000	24	6600.00	80.00	66800.00
2	2026-02-12	1	5.000	5.000	24	7658.00	82.00	38700.00
1	2026-04-17	1	5.000	5.000	24	8069.00	71.00	40700.00
\.


--
-- Data for Name: growth_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.growth_snapshots (id, snapshot_date, value) FROM stdin;
1	2026-06-01	9940.00
2	2026-07-01	14962.00
\.


--
-- Data for Name: portfolio_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.portfolio_settings (id, emergency_fund_target, usd_egp_rate) FROM stdin;
1	60000.00	49.2300
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transactions (id, asset_type, name, meta, occurred_at, amount, tx_type) FROM stdin;
1	abr	Bareeq Fund	24 units @ EGP 207.695	2026-07-05 12:09:00+00	4984.80	buy
2	abr	Bareeq Fund	48 units @ EGP 206.988	2026-06-26 11:20:00+00	9935.52	buy
3	re	Beltone Real Estate Fund	2,656 units @ EGP 1.888	2026-06-16 13:40:00+00	5019.84	buy
8	gold	Gold 24K	2 bars x 5g @ 6,600 EGP/g + 80 EGP/g fee	2025-12-15 12:00:00+00	66800.00	buy
9	gold	Gold 24K	1 bar x 5g @ 7,658 EGP/g + 82 EGP/g fee	2026-02-12 12:00:00+00	38700.00	buy
10	gold	Gold 24K	1 bar x 5g @ 8,069 EGP/g + 71 EGP/g fee	2026-04-17 12:00:00+00	40700.00	buy
\.


--
-- Name: certificates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.certificates_id_seq', 25, true);


--
-- Name: funds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.funds_id_seq', 2, true);


--
-- Name: gold_holdings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gold_holdings_id_seq', 1, true);


--
-- Name: gold_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gold_settings_id_seq', 1, true);


--
-- Name: gold_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gold_transactions_id_seq', 5, true);


--
-- Name: growth_snapshots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.growth_snapshots_id_seq', 3, true);


--
-- Name: portfolio_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.portfolio_settings_id_seq', 1, true);


--
-- Name: transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.transactions_id_seq', 10, true);


--
-- Name: certificates certificates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_pkey PRIMARY KEY (id);


--
-- Name: funds funds_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.funds
    ADD CONSTRAINT funds_key_unique UNIQUE (key);


--
-- Name: funds funds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.funds
    ADD CONSTRAINT funds_pkey PRIMARY KEY (id);


--
-- Name: gold_holdings gold_holdings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gold_holdings
    ADD CONSTRAINT gold_holdings_pkey PRIMARY KEY (id);


--
-- Name: gold_settings gold_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gold_settings
    ADD CONSTRAINT gold_settings_pkey PRIMARY KEY (id);


--
-- Name: gold_transactions gold_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gold_transactions
    ADD CONSTRAINT gold_transactions_pkey PRIMARY KEY (id);


--
-- Name: growth_snapshots growth_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.growth_snapshots
    ADD CONSTRAINT growth_snapshots_pkey PRIMARY KEY (id);


--
-- Name: portfolio_settings portfolio_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portfolio_settings
    ADD CONSTRAINT portfolio_settings_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict HmShIgdyt9zxFTkJUw68iyi8SfGoZ6Uft3PHZ82992ydVQwgKdLp8srKMt48Uwl

